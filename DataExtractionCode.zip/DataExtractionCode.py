from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
import pandas as pd
from selenium.webdriver.common.by import By  # Import the By module



driver = webdriver.Chrome()

driver.get("https://www.bisesahiwal.edu.pk/allresult/")


data = []
#300024--344417
for i in range(514000, 514417):
    try:
        class_select = Select(driver.find_element(By.NAME, "class"))
        class_select.select_by_visible_text("12TH")

        year_select = Select(driver.find_element(By.NAME, "year"))
        year_select.select_by_visible_text("2022")

        sess_select = Select(driver.find_element(By.NAME, "sess"))
        sess_select.select_by_visible_text("SUPPLY")

        # Put roll number and view result
        roll_number_input = driver.find_element(By.NAME, "rno")
        roll_number_input.clear()
        roll_number_input.send_keys(i)
        driver.find_element(By.NAME, "commit").click()


        driver.implicitly_wait(5)

        # student name
        name = driver.find_element(By.XPATH,
                                   '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr[1]/td[2]/span').text
        # father name
        father = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr[2]/td[2]/span').text

        # status
        status = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr/td[1]/p/u').text

        # rollno
        rollno = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table/tbody/tr/td[3]/p[1]/u').text

        # institue_district
        institue_district = driver.find_element(By.XPATH,
                                                '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table/tbody/tr[3]/td[2]/span').text


        # subject1
        s1 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[2]').text


        p1 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[6]').text


        grade1 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[9]').text

        total1 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[3]').text

        # Obtained_Marks
        obtained1I = driver.find_element(By.XPATH,
                                         '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[4]').text
        # Obtained_Marks
        obtained1II = driver.find_element(By.XPATH,
                                          '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[5]').text

        # subject2
        s2 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td[2]').text


        p2 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td[6]').text

        ############
        grade2 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td[9]').text
        total2 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td[3]').text

        # Obtained_Marks
        obtained2I = driver.find_element(By.XPATH,
                                         '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td[4]').text
        # Obtained_Marks
        obtained2II = driver.find_element(By.XPATH,
                                          '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td[5]').text

        # subject3
        s3 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[6]/td[2]').text


        p3 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[6]/td[6]').text
        ############
        grade3 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[6]/td[9]').text

        total3 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[6]/td[3]').text

        # Obtained_Marks
        obtained3I = driver.find_element(By.XPATH,
                                         '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[6]/td[4]').text
        # Obtained_Marks
        obtained3II = driver.find_element(By.XPATH,
                                          '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[6]/td[5]').text

        # subject4
        s4 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[7]/td[2]').text


        p4 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[7]/td[6]').text
        ############
        grade4 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[7]/td[9]').text

        total4 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[7]/td[3]').text

        # Obtained_Marks
        obtained4I = driver.find_element(By.XPATH,
                                         '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[7]/td[4]').text
        # Obtained_Marks
        obtained4II = driver.find_element(By.XPATH,
                                          '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[7]/td[5]').text

        # subject5
        s5 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[8]/td[2]').text


        p5 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[8]/td[6]').text
        ############
        grade5 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[8]/td[9]').text

        total5 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[8]/td[3]').text

        # Obtained_Marks
        obtained5I = driver.find_element(By.XPATH,
                                         '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[8]/td[4]').text
        # Obtained_Marks
        obtained5II = driver.find_element(By.XPATH,
                                          '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[8]/td[5]').text

        # subject6
        s6 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[10]/td[2]').text


        p6 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[10]/td[6]').text
        ############
        grade6 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[10]/td[9]').text

        total6 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[10]/td[3]').text

        # Obtained_Marks
        obtained6I = driver.find_element(By.XPATH,
                                         '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[10]/td[4]').text
        # Obtained_Marks
        obtained6II = driver.find_element(By.XPATH,
                                          '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[10]/td[5]').text

        # subject7
        s7 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[9]/td[2]').text


        p7 = driver.find_element(By.XPATH,
                                 '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[9]/td[6]').text
        ############
        grade7 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[9]/td[9]').text

        total7 = driver.find_element(By.XPATH,
                                     '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[9]/td[3]').text

        # Obtained_Marks
        obtained7I = driver.find_element(By.XPATH,
                                         '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[9]/td[4]').text
        # Obtained_Marks
        obtained7II = driver.find_element(By.XPATH,
                                          '/html/body/div[1]/div[2]/table/tbody/tr/td[2]/table/tbody/tr[5]/td/table/tbody/tr[9]/td[5]').text

        # Append data to the list
        data.append({
            "Name": name,
            "Roll Number": rollno,
            "Father Name": father,
            "Institute/District": institue_district,

            "Status": status,

            "Subject 1": s1,
            # "Practical1": p1,
            "Total1": total1,
            "Grade 1": grade1,
            "obtained 11th(1)": obtained1I,
            "obtained 12th(1)": obtained1II,

            "Subject 2": s2,
            # "Practical 2": p2,
            "Total2": total2,
            "Grade 2": grade2,
            "obtained 11th(2)": obtained2I,
            "obtained 12th(2)": obtained2II,

            "Subject 3": s3,
            # "Practical 3": p3,
            "Total3": total3,
            "Grade 3": grade3,
            "obtained 11th(3)": obtained3I,
            "obtained 12th(3)": obtained3II,

            "Subject 4": s4,
            # "Practical4": p4,
            "Total4": total4,
            "Grade 4": grade4,
            "obtained 11th(4)": obtained4I,
            "obtained 12th(4)": obtained4II,

            "Subject 5": s5,
            "Practical5": p5,
            "Total5": total5,
            "Grade 5": grade5,
            "obtained 11th(5)": obtained5I,
            "obtained 12th(5)": obtained5II,

            "Subject 6": s6,
            "Practical6": p6,
            "Total 6": total6,
            "Grade 6": grade6,
            "obtained 11th(6)": obtained6I,
            "obtained 12th(6)": obtained6II,

            "Subject 7": s7,
            "Practical7": p7,
            "Total7": total7,
            "Grade 7": grade7,
            "obtained 11th(7)": obtained7I,
            "obtained 12th(7)": obtained7II,
            # Add more subjects here...
        })

        print(f"Successfully scraped data for Roll Number: {i}")

        # Going  back to the initial page
        driver.back()
    except NoSuchElementException as exception:
        print(f"Skipping Roll Number: {i} due to NoSuchElementException")
        driver.quit()

        driver = webdriver.Chrome()

        driver.get("https://www.bisesahiwal.edu.pk/allresult/")
        continue

# Close the browser
driver.quit()

# Create a DataFrame from the list of data
df = pd.DataFrame(data)

# Save the DataFrame to an Excel file
df.to_excel("Sahiwal_Annual_12.xlsx", index=False)